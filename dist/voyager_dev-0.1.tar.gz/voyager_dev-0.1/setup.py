from setuptools import setup
setup(name="voyager_dev", version="0.1", packages=["voyager_dev"], entry_points={"console_scripts": ["voyager_dev=voyager_dev.voyager_dev:main"]})
